// client/src/utils/api.js
import axios from "axios";

const SERVER_BASE = process.env.REACT_APP_SERVER_BASE || "http://localhost:5000";

const API = axios.create({ baseURL: SERVER_BASE });

// attach JWT automatically
API.interceptors.request.use(cfg => {
  const token = localStorage.getItem("token");
  if (token) cfg.headers.Authorization = `Bearer ${token.replace(/^"(.*)"$/, "$1")}`;
  return cfg;
});

export default API;
