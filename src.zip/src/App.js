// client/src/App.js
import React from "react";
import { BrowserRouter, Routes, Route, Navigate, Link } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UploadPage from "./pages/UploadPage";
import DatasetsPage from "./pages/DatasetsPage";
import "./styles.css";

export default function App() {
  const isAuthenticated = !!localStorage.getItem("token");

  return (
    <BrowserRouter>
      <header className="header">
        <h1 style={{ margin: 0 }}>LeafGAN</h1>
        <nav>
          <Link to="/">Home</Link>{" "}
          <Link to="/upload">Upload</Link>{" "}
          <Link to="/datasets">My Datasets</Link>{" "}
          {!isAuthenticated && <Link to="/login">Login</Link>}
          {!isAuthenticated && <Link to="/register">Register</Link>}
          {isAuthenticated && (
            <button
              onClick={() => {
                localStorage.removeItem("token");
                window.location.href = "/"; // refresh to update UI
              }}
            >
              Logout
            </button>
          )}
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={isAuthenticated ? <Home /> : <Navigate to="/login" replace />} />
          <Route path="/upload" element={isAuthenticated ? <UploadPage /> : <Navigate to="/login" replace />} />
          <Route path="/datasets" element={isAuthenticated ? <DatasetsPage /> : <Navigate to="/login" replace />} />
          <Route path="/login" element={!isAuthenticated ? <Login /> : <Navigate to="/" replace />} />
          <Route path="/register" element={!isAuthenticated ? <Register /> : <Navigate to="/" replace />} />
          <Route path="*" element={<Navigate to={isAuthenticated ? "/" : "/login"} replace />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}
