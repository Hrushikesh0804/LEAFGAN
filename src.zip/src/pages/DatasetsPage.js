import React, { useEffect, useState } from 'react';
import API from '../utils/api';
export default function DatasetsPage(){
  const [list,setList] = useState([]);
  useEffect(()=>{ async function load(){ try{
    const res = await API.get('/datasets'); setList(res.data);
  } catch(e){ console.error(e);} } load(); },[]);
  return (
    <div>
      <h3>My Datasets</h3>
      <ul>
        {list.map(d => (
          <li key={d._id}>
            {d.plantName} — {d.originalFilename} — {d.status}
            {d.augmentedFilename && <span> — <a href={`${process.env.REACT_APP_SERVER_BASE || 'http://localhost:5000'}/downloads/${d.augmentedFilename}`} target="_blank" rel="noreferrer">Download</a></span>}
          </li>
        ))}
      </ul>
    </div>
  );
}
