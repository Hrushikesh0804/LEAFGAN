import React from 'react';
import LeafShowcase from '../components/LeafShowcase';

export default function Home(){
  return (
    <div>
      <section className="hero" style={{ alignItems: 'flex-start' }}>
        <div className="hero-left" style={{ flex: 1 }}>
          <h2 style={{ color: 'var(--leaf-green)', marginBottom: 8 }}>LeafGAN: An Effective Data Augmentation Method
for Practical Plant Disease Diagnosis</h2>

          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            <div style={{ flex: 1, background: '#fff', padding: 14, borderRadius: 10, boxShadow: '0 6px 18px rgba(10,80,30,0.06)' }}>
              <h4 style={{ margin: '0 0 8px 0' }}>LFLSeg — Label-free leaf segmentation module</h4>
              <p style={{ margin: 0, color: '#334' }}>
                <strong>LFLSeg</strong> is a practical segmentation approach tuned for leaf images: it quickly masks
                leaf regions from backgrounds so augmentation and disease synthesis operate only on leaf pixels.
                That means cleaner augmented data, fewer artifacts, and smaller models that train faster.
              </p>
              <ul style={{ marginTop: 8 }}>
                <li>Pixel-accurate masks for augmentation safety</li>
                <li>Fast inference — useful on-device for field apps</li>
              </ul>
            </div>

            <div style={{ flex: 1, background: '#fff', padding: 14, borderRadius: 10, boxShadow: '0 6px 18px rgba(80,30,10,0.04)' }}>
              <h4 style={{ margin: '0 0 8px 0' }}>GAN — Realistic disease synthesis</h4>
              <p style={{ margin: 0, color: '#334' }}>
                Generative Adversarial Networks (GANs) create realistic disease patterns that are otherwise
                rare in datasets — from subtle spots to advanced necrosis. When combined with LFLSeg masks,
                GAN outputs stay on-leaf and preserve natural textures.
              </p>
              <ul style={{ marginTop: 8 }}>
                <li>Synthesizes diverse disease morphologies</li>
                <li>Improves model robustness and reduces bias</li>
              </ul>
            </div>
          </div>

          <h3 style={{ marginTop: 6 }}>Why this matters — short & punchy</h3>
          <p style={{ lineHeight: 1.6 }}>
            Real field conditions are messy: lighting changes, partial occlusion, and uncommon disease variants.
            LeafGAN combines targeted <em>LFLSeg</em> masking with GAN-driven augmentation to produce realistic,
            high-quality training sets so detection models generalize better to the real world.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 14 }}>
            <div style={{ background: '#e9f8ef', padding: 12, borderRadius: 10 }}>
              <strong>Use cases</strong>
              <ul>
                <li>Rapidly expand rare-disease samples</li>
                <li>Augment datasets for low-data crops</li>
                <li>On-device inference with smaller networks</li>
              </ul>
            </div>
            <div style={{ background: '#fffbe9', padding: 12, borderRadius: 10 }}>
              <strong>Impact</strong>
              <p style={{ margin: 0 }}>Less manual labeling • Faster prototyping • More robust models in the field</p>
            </div>
          </div>

          <p style={{ marginTop: 12 }}>
            Github: <a href="https://github.com/Hrushikesh0804/LEAFGAN" target="_blank" rel="noreferrer">LEAFGAN on GitHub</a>
          </p>
        </div>

        <div className="hero-right" style={{ width: 420 }}>
          <LeafShowcase />
          <div style={{ marginTop: 12, fontSize: 13, color: '#444' }}>
         <strong>LFLSeg + GAN</strong> effect.
          </div>
        </div>
      </section>

      <section className="explain" style={{ marginTop: 28 }}>
        <h3>Design thinking — how we combine the pieces</h3>
        <p>
          We first segment the leaf (LFLSeg) to constrain augmentation to meaningful pixels. GANs then synthesize
          realistic disease textures which are composited into the masked leaf. This pipeline preserves the
          photorealism of veins and edges while adding helpful diversity.
        </p>
      </section>
    </div>
  );
}
