import React from "react";
import healthyUrl from "./healthy.png";
import diseasedUrl from "./des.png";

export default function LeafShowcase() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        gap: "30px",
        marginTop: "20px",
        flexWrap: "wrap",
      }}
    >
      <div
        style={{
          textAlign: "center",
          background: "#f9fff9",
          borderRadius: "12px",
          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
          padding: "12px",
          width: "280px",
        }}
      >
        <img
          src={healthyUrl}
          alt="Healthy leaf"
          style={{
            width: "100%",
            height: "220px",
            objectFit: "cover",
            borderRadius: "8px",
          }}
        />
        <h4 style={{ color: "#1f7a3e", marginTop: "10px" }}>Healthy Leaf</h4>
      </div>

      <div
        style={{
          textAlign: "center",
          background: "#fff9f9",
          borderRadius: "12px",
          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
          padding: "12px",
          width: "280px",
        }}
      >
        <img
          src={diseasedUrl}
          alt="Diseased leaf"
          style={{
            width: "100%",
            height: "220px",
            objectFit: "cover",
            borderRadius: "8px",
          }}
        />
        <h4 style={{ color: "#a52a2a", marginTop: "10px" }}>Diseased Leaf</h4>
      </div>
    </div>
  );
}
