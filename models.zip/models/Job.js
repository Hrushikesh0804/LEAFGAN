const mongoose = require('mongoose');
const JobSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  dataset: { type: mongoose.Schema.Types.ObjectId, ref: 'Dataset' },
  jobId: String,
  status: { type: String, enum: ['pending','processing','done','failed'], default: 'pending' },
  readyAt: Date,
  outputFilename: String,
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Job', JobSchema);
