const mongoose = require('mongoose');
const DatasetSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  plantName: String,
  originalFilename: String,
  augmentedFilename: String,
  status: { type: String, enum: ['processing','done','failed'], default: 'processing' },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Dataset', DatasetSchema);
