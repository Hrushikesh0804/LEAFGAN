// server/routes/ai.js (CommonJS)
const express = require('express');

const router = express.Router();

// Use global fetch (Node 18+ has fetch). If you have an older node, install node-fetch and require it.
const fetchFn = (typeof fetch !== 'undefined') ? fetch : require('node-fetch');

router.post('/search', async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ message: 'Query required' });

  try {
    const response = await fetchFn('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'You are an expert in plant pathology. Give concise, educational answers about leaf diseases and their effects.' },
          { role: 'user', content: query }
        ],
        temperature: 0.7,
        max_tokens: 600
      })
    });

    const data = await response.json();
    const answer = data?.choices?.[0]?.message?.content || 'No result found.';
    res.json({ answer });
  } catch (err) {
    console.error('AI route error:', err);
    res.status(500).json({ message: 'Error fetching AI response.' });
  }
});

module.exports = router;
