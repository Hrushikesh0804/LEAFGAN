const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const asyncHandler = require('express-async-handler');
const AdmZip = require('adm-zip');
const sharp = require('sharp');

const auth = require('../middleware/auth');
const Dataset = require('../models/Dataset');
const Job = require('../models/Job');

const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
if(!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, `${Date.now()}_${file.originalname}`)
});
const upload = multer({ storage, limits: { fileSize: 200 * 1024 * 1024 } }); // 200MB

// POST /api/upload -> accepts training zip & plantName
router.post('/upload', auth, upload.single('trainingZip'), asyncHandler(async (req, res) => {
  if(!req.file) return res.status(400).json({ message: 'No file uploaded' });

  const plantName = req.body.plantName || 'unknown';
  // create dataset record
  const ds = await Dataset.create({
    user: req.userId,
    plantName,
    originalFilename: req.file.filename,
    status: 'processing'
  });

  const jobId = uuidv4();
  // set readyAt = now + 3 minutes
  const readyAt = new Date(Date.now() + 3 * 60 * 1000);

  const job = await Job.create({
    user: req.userId,
    dataset: ds._id,
    jobId,
    status: 'processing',
    readyAt
  });

  // Note: we **do not** run heavy augmentation here. The server will generate the augmentation
  // on-demand when client requests /download/:jobId and current time >= readyAt.
  // This avoids background workers while still enforcing the 3-minute wait behavior.

  res.json({
    jobId,
    datasetId: ds._id,
    readyAt: readyAt.toISOString(),
    message: 'Processing started. Augmented dataset will be available in ~3 minutes.'
  });
}));

// GET /api/status/:jobId
router.get('/status/:jobId', auth, asyncHandler(async (req, res) => {
  const job = await Job.findOne({ jobId: req.params.jobId }).populate('dataset');
  if(!job) return res.status(404).json({ message: 'Job not found' });

  const now = new Date();
  const ready = now >= job.readyAt;
  res.json({
    jobId: job.jobId,
    status: ready ? (job.status === 'done' ? 'done' : 'ready' ) : job.status,
    readyAt: job.readyAt,
    outputAvailable: job.status === 'done'
  });
}));

// GET /api/download/:jobId -> returns augmented zip if ready (creates it on-demand if not present)
router.get('/download/:jobId', auth, asyncHandler(async (req, res) => {
  const job = await Job.findOne({ jobId: req.params.jobId }).populate('dataset');
  if(!job) return res.status(404).json({ message: 'Job not found' });

  const now = new Date();
  if(now < job.readyAt) {
    const remain = Math.ceil((job.readyAt - now)/1000);
    return res.status(423).json({ message: `Not ready yet. wait ${remain} seconds.` });
  }

  // if already done and output exists, serve it
  if(job.status === 'done' && job.outputFilename) {
    const outPath = path.join(UPLOAD_DIR, job.outputFilename);
    if(fs.existsSync(outPath)) return res.download(outPath);
  }

  // Make output filename
  const outName = `Augmented_dataset_${job.jobId}.zip`;
  const outPath = path.join(UPLOAD_DIR, outName);

  // If you have a prepared sample augmented zip in uploads named sample_aug.zip, copy it (fast simulation)
  const sampleAugPath = path.join(UPLOAD_DIR, 'sample_aug.zip');
  if(fs.existsSync(sampleAugPath)) {
    fs.copyFileSync(sampleAugPath, outPath);
    job.status = 'done';
    job.outputFilename = outName;
    await job.save();
    // update dataset meta
    await Dataset.findByIdAndUpdate(job.dataset._id, { augmentedFilename: outName, status: 'done' });
    return res.download(outPath);
  }

  // Otherwise, do a simple augmentation pipeline now (extract uploaded zip -> flip/rotate -> zip)
  try {
    const origZipPath = path.join(UPLOAD_DIR, job.dataset.originalFilename);
    const workDir = path.join(UPLOAD_DIR, `work_${job.jobId}`);
    const augDir = path.join(UPLOAD_DIR, `aug_${job.jobId}`);
    fs.mkdirSync(workDir, { recursive: true });
    fs.mkdirSync(augDir, { recursive: true });

    // extract
    const zip = new AdmZip(origZipPath);
    zip.extractAllTo(workDir, true);

    // find images
    const exts = ['.jpg','.jpeg','.png','.bmp','.webp'];
    const images = [];
    (function walk(dir){
      for(const it of fs.readdirSync(dir)) {
        const full = path.join(dir, it);
        if(fs.statSync(full).isDirectory()) walk(full);
        else if(exts.includes(path.extname(it).toLowerCase())) images.push(full);
      }
    })(workDir);

    // augment each (orig + flipped + rotated)
    await Promise.all(images.map(async (imgPath) => {
      const base = path.basename(imgPath, path.extname(imgPath));
      const ext = path.extname(imgPath).toLowerCase();
      const buf = fs.readFileSync(imgPath);
      fs.writeFileSync(path.join(augDir, `${base}_orig${ext}`), buf);
      const flip = await sharp(buf).flip().toBuffer();
      fs.writeFileSync(path.join(augDir, `${base}_flip${ext}`), flip);
      const rot = await sharp(buf).rotate(90).toBuffer();
      fs.writeFileSync(path.join(augDir, `${base}_rot90${ext}`), rot);
    }));

    // zip augmented dir
    const outZip = new AdmZip();
    (function addAll(dir, relRoot=''){
      for(const it of fs.readdirSync(dir)){
        const full = path.join(dir, it);
        if(fs.statSync(full).isDirectory()) addAll(full, path.join(relRoot, it));
        else outZip.addLocalFile(full, relRoot);
      }
    })(augDir);
    outZip.writeZip(outPath);

    // cleanup work/aug dirs
    fs.rmSync(workDir, { recursive: true, force: true });
    fs.rmSync(augDir, { recursive: true, force: true });

    job.status = 'done';
    job.outputFilename = outName;
    await job.save();
    await Dataset.findByIdAndUpdate(job.dataset._id, { augmentedFilename: outName, status: 'done' });

    return res.download(outPath);
  } catch (err) {
    console.error('augmentation error', err);
    job.status = 'failed';
    await job.save();
    await Dataset.findByIdAndUpdate(job.dataset._id, { status: 'failed' });
    return res.status(500).json({ message: 'Augmentation failed', error: err.message });
  }
}));

// simple list datasets for user
router.get('/datasets', auth, asyncHandler(async (req, res) => {
  const ds = await Dataset.find({ user: req.userId }).sort({ createdAt: -1 });
  res.json(ds);
}));

module.exports = router;
